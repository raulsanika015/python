no1=int(input("Enter number:"))
no2=int(input("Enter number"))
if no1>no2:
     print(no1," is greater")
else:
     print(no2," is greater")
