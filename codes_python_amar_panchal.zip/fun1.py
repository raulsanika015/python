def printer( passed ):
   "This prints a passed string"
   print ("this is function printing:praramemter of type ",type(passed),\
          " is ",passed)
   return

printer("String")
printer(120)
printer(4.5)
