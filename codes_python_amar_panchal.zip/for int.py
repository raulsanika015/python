line=input("Enter line:")

for i in line:
     print(i)
                    


