a=int(input("Enter a number:"))
b=int(input("Enter a number:"))
c=a+b
print("Addition of ",a," and ",b," is ",c)
print(" addition of %f and %f is %h"%(a,b,c))


