def max(*names):
     sum=0
     for v in names:
          sum+=v
       
     return sum

