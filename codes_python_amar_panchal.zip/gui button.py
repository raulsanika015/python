from tkinter import *
top=Tk()
B = Button(top, text='Hello',bd=15,bg="#00ff00")
B.pack()
top.mainloop( )

