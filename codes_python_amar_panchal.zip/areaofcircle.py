r=float(input("Enter Radius:"))
print("Area of circle is",(3.14*r*r))
