
from tkinter import *

root = Tk()
root.title("Hello")
top = Toplevel()
top.title("Challo")
top.mainloop()












