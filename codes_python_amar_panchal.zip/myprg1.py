print("hi this is the script")
