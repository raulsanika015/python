def max(no1,no2):
     if no1>no2:
          print("Maximum is:",no1);
     else:
          print("Maximum is:",no2);
     return


     
     
