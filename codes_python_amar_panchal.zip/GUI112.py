from tkinter import *#importing all classes from tkinter
root = Tk( )#creating instance of window
root.title("A simple window")#name of window
root.geometry('250x250+50+50')#width height x and y position to display
    

root.mainloop( )#most imp to start window
