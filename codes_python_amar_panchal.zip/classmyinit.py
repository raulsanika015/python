class My:
      def __init__(self,d1=0,d2=0):
           self.data1=d1
           self.data2=d2
           
      def set_data(self,data1,data2):
           self.data1=data1
           self.data2=data2
          
      def print_data(self):
          print("data1:",self.data1," data2:",self.data2)
