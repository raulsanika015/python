class my:
     
      def set_data(self,data1,data2):
           self.data1=data1
           self.data2=data2
          
      def print_data(self):
          print("data1:",self.data1," data2:",self.data2)
                    
          
m=my()
n=my()
k=my()


