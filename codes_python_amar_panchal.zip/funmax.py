def max(no1,no2):
     if no1>no2:
          return no1;
     else:
          return no2;

     
     
