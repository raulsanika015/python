print("hi this is line 1")
print('this is it line 2')
print('''hi hi line 3 ''')
