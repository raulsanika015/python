flag = 1
while (flag): print ('Given flag is really true!')
print ("Good bye!")

