marks=float(input('enter a number:'))

print((marks*100)/600)
