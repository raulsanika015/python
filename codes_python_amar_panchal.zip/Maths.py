class Maths:
       def add(self,d1,d2,d3):
          print("3 ka Addision of is:",(data1+data2+data3))
       def add(self,data1,data2):
          print(" 2 ka Addision of is:",(data1+data2))

m=Maths()
m.add(1,3)

