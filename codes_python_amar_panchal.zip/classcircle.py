#area of circle
class Circle:

     def set_radius(self,r):
          self.r=r
          self.display_area()

     def display_area(self):
          print("Area of Circle is:",(3.14*self.r*self.r))


          
