from tkinter import *

top = Tk()

w = Spinbox(top, from_= 0,to = 10)
w.pack()
top.mainloop()
