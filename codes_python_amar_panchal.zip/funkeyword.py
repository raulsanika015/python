def intro(name,age,pointer=1.0):
     print("Name:",name,"\nAge:",age,"\nPointer:",pointer)
     return

intro(pointer=10.9,age=33,name="amar")
 
