from tkinter import *
top=Tk()
msg = Message(top, text='This is it It is now or never')
msg.pack()
mainloop()
