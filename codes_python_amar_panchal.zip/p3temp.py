tf=float(input("Enter temp:"))
print("Temprature in Temp C: ",((tf-32)/1.8))


