class A:
     def __init__(self):
          print("this is my init")
     def __del__(self):
          print("this is my del")
     def __str__(self):
          return("Class A:this is my str")

class X:
     def __init__(self):
          print("Created")
          
     
class adder:
     def __init__(self):
          print("created")
          
     def add(self,a,b,c=0):
          print("Add ",(a+b+c))







          
          
