class imp:
     def __init__(self):
          print("self called:")
     def __printer__(self):
          print("printer printer")
          
     
