for i in "python":
     print(i)
