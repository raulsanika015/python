n=int(input("Enter n:"));
for i in range(1,n):
                    print(i)
