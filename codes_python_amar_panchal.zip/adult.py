a=int(input("Enter age:"))
if a<18:
     print("Minor go home")
else:
     print("Adult can stay")
