class my:
     __mydata=0
     def __init__(self):
          my.mydata=0
     def access(self,data):
         # self.data=data
          print(data)


     


