print("Enter 3 numbers")
a=int(input())#100
b=int(input())#10
c=int(input())#3
if a<b and a<c:
               print(a," is minimum")
     
elif b<c and b<a:
               print(b," is minimum")
     
else:
     print(c," is minimum")
          
