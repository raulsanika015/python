from tkinter import *
l=Button(None,text="end me")
l.pack()
l.mainloop()
