for i in range(10):
    print( i);
input("\enter any key to quit")
