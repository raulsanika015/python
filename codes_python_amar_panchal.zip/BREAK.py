for letter in 'Python': 
  if letter == 'h':
              break
  print ('Current Letter :', letter)
print ('code still runs :')
