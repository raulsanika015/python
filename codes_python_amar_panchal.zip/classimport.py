from classmyinit import My
m=My()
m.set_data(100,200)
m.print_data()
