class override:
     def __init__(self):
          print("this is my init")
     def __del__(self):
          print("duaoo mai yaad rakhna")
     def __str__(self):
          print("i m override")
          
     
