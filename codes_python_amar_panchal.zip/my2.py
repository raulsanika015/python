name = input("What's your name? ")
print("Nice to meet you " + name + "!")
age = input("Your age? ")
print("So, you are just" + str(age) + " years old, " + name + "!")


