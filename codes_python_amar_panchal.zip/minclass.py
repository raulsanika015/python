class number:
     a=0
     b=0
     def __init__(self):
          printf("parent created")
     def setattr(self,at,bt):
          number.a=at
          number.b=bt
          
class min(number):
     def __init__(self):
          print("child created")
     def min(self):
          if(number.a<number.b):
               print(number.a)
          else:
               print(number.b)
     

     
