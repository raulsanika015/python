def myfun(a):
     a=[11,22,33]
     print("in function:",a)
     return

a=[10,20,30]
print("Before function:",a)
myfun(a)
print("After function:",a)
