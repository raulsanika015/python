dict = {}
dict['one'] = "This is one"
dict[2] = "This is two"
tinydict = {'name': 'john','code':6734, 'dept': 'sales'}
print (dict['one']) 
print (dict[2]) 
print (tinydict)
print (tinydict.keys())
print (tinydict.values())
