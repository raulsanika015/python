sec=int(input("Enter time:"))#4800
h=int(sec/3600)
m=int((sec%3600)/60)
s=sec%60;
print("Time in seconds:",sec,"in hh:mm:ss",h,":",m,":",s)


