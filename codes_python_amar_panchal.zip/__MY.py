a=input("Enter a number:");
b=input("Enter a number:");
if (a>b):
     print("Maximum is ",a)
else:
     print("Maximum is ",b)
