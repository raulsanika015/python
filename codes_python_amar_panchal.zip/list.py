fruits = ['orange', 'apple', 'pear', 'banana', 'kiwi', 'apple', 'banana']
fruits.count('apple')
fruits.count('tangerine')
fruits.index('banana')
fruits.index('banana', 4) 
fruits.reverse()
fruits
fruits.append('grape')
fruits
fruits.sort()
fruits
fruits[-1]
fruits.count('grape')
fruits.index('grape')


