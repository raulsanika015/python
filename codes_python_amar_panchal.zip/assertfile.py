def age(a):
     assert(a>0),"Negative age given"
     print("Age is :",a)
     return
