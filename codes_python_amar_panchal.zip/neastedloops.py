for i in range(1,6):#1           2      3
     for j in range(1,i+1):#1    1 2    1 2 3
          print("* ",end=' ')
     print()
          
