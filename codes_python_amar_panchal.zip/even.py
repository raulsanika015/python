a=int(input("Enter number:"))
if a!=0 and a%2!=0:
     print(a," is not even")
else:
     print(a," is even")
