#taking input
a=int(input("Enter a number:"))#one 
b=int(input("Enter another number:"))#two
print("Addition:",a+b)#answer
print("Addition of",a,"and",b,"is",a+b) 
#Addition of 12 and 22 is 34
