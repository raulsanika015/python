hm=float(input("Enter time:"))#1.20
h=int(hm)#1        .20
m=(hm-h)*100#1.20-1--->.20-->*100-->20
sec=int(h*3600+m*60)
print("Time ",hm," Converted to Seconds:",sec)

