s=input("Enter name:")
age=int(input("Enter age:"))
print("Welcome %s, Your age is %d"%(s,age))
