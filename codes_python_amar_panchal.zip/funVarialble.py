def intro(*names):
     for v in names:
          print(type(v)," ",v)
     return

