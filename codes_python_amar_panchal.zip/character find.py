s1=input("Enter word to check:")
s1=s1.lower()
c=s1.count("a")+s1.count("e")+s1.count("i")+s1.count("o")+s1.count("u")
print("Number of vowels:",c)
