def my(integer,floating,characters):
     print(type(integer)," ",integer,"\n",type(floating)," ",
           floating,"\n",type(characters)," ",characters)
     return

my(characters="abcd3",integer=77733,floating=5.66)
#variable identifiers from function parameters
