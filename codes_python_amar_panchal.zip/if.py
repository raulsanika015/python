a=15
if a<10:
       print("a is smaller")
       print("a is still")
       print("a is smaller3")
       print("a is smaller last")
