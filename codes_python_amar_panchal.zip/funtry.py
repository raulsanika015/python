def lister(*MyList):
     print("List received:\n")
     for i in MyList:
          print(i)
     return

lister("aa","SSS","wwe3",1234)
     
   
