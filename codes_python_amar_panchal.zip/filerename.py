import os
os.rename("MyFile.txt","yous.dat")
