number1 = input(" Please Enter the First Number: ")
number2 = input(" Please Enter the second number: ")
sum = number1 + number2+8
print (sum)
