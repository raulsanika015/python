class Human:
     abadi=0
     def __init__(self):
          Human.abadi+=1
          print("increased")

     def total_abadi(self):
          print("Total abadi:",Human.abadi)


