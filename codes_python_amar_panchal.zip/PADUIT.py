age=float(input('enter number:'))
if age >=18:
    print('he/she is adult')
else:
     print('he/she is minor')
