def add(a,b):
     "Addition of two numbers"
     print("data passed is:",a," ",b)
     print("Addition is =",(a+b))
     return

print("enter 2 numbers")
a=int(input())
b=int(input())
add(a,b)
