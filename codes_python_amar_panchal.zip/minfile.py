def min(a,b):
     if a<b:
          return(a)
     else:
          return(b)
     
no1=int(input("Enter number 1:"))
no2=int(input("Enter number 2:"))
no3=int(input("Enter number 3:"))
ans=min(no1,min(no2,no3))
print("minimum is",ans)
