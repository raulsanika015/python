class Me:
     def __init__(self):
          print("Object of Me created",self)
     def __del__(self):
          print("Object about to be deleted",self)
     
