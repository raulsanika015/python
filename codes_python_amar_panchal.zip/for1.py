a=[11,22,33,44,55,66]
for i in a:
     print(i)
     
