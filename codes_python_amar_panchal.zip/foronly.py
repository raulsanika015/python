for i in "abcdefghijklmnopqrst":
                                        print(i)
                    
