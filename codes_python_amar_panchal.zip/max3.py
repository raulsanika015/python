a=int(input("Enter a number:"))
b=int(input("Enter a number:"))
c=int(input("Enter a number:"))
if (a>b and a>c):
       print("max:",a)
      
elif (b>a and b>c):
       print("max:",b)
else:
    print("max:",c)
       
