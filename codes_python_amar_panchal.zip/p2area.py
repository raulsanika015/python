r=float(input("Enter radius:"))
area=3.14*r*r
print("area of circle is ",area)



