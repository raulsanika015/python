for i in "hi huku hi huku hi hi":
                    print(i);
                    
