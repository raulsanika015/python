n=int(input("Enter number of times"))
s=input("Enter your name:")
print(s*n)
