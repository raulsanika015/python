print("Enter marks of 5 subjects")
m1=int(input())
m2=int(input())
m3=int(input())
m4=int(input())
m5=int(input())
total=m1+m2+m3+m4+m5
percentage=total/500*100
print("Percentage:",percentage)
